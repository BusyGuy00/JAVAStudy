package day15.Book;

public class Container<T> {
	private T t;
	
	//getter
		public T get () {
			return t;
		}
		//Setter 
		public void set (T t) {
			this.t = t;
		}
		
}
