package day15.Book;

public class Container2<T, K> {
	
	private T Key;
	private K Value;
	
	//getter
		public T getKey() {
			return Key ;
		}
		public K geyValue() {
			return Value ;
		}
		
	//Setter
		public void set (T Key, K Value) {
			this.Key =Key;
			this.Value =Value;
		}
	
}
