package day15.Exam03;

public class Home {
	public void turnOnLight() {
		System.out.println("전등을 켭니다.");
	}
}
