package day15.Exam03;

public interface Rentable<P> {
	//추상메소드 atstract생략 가능 
	P rent(); // rent 라는 타입이 오면 리턴 된다.
	

}
